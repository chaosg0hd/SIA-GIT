import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salarypage',
  templateUrl: './salarypage.component.html',
  styleUrls: ['./salarypage.component.css']
})
export class SalarypageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
