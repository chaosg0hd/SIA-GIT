import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userspage',
  templateUrl: './userspage.component.html',
  styleUrls: ['./userspage.component.css']
})
export class UserspageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
